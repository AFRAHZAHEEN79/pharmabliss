<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "pharmacy");

// Check connection
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}

// SQL query to retrieve data
$sql = "SELECT * FROM data2";
$result = mysqli_query($conn, $sql); //[Adnan Ali, adduadnanali@gmail.com, Nice one] //Gayathri ggpv@gmail.com Great Quality
?>

<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customer Reviews</title>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>


<div class="container mt-5">
<table class="table">
 <thead class="table-dark">
 <tr>
 <th>FirstName</th>
 <th>LastName</th>
 <th>Email</th>
 <th>Subject</th>
 <th>Message</th>
 </tr>
 </thead>
 <tbody>
 <?php
 if (mysqli_num_rows($result) > 0) {
 while ($row = mysqli_fetch_assoc($result)) {
 echo "<tr>";
echo "<td>" . $row["FirstName"] . "</td>";
   echo "<td>" . $row["LastName"] . "</td>";
 echo "<td>" . $row["Email"] . "</td>";
 echo "<td>" . $row["Subject"] . "</td>";
  echo "<td>" . $row["Message"] . "</td>";   
echo "</tr>";
 }
 } else {
 echo "<tr><td colspan='5'>No records found</td></tr>";
 }
?>
 </tbody>
 <a href="index.html" class="btn btn-dark">Go Back</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Close connection
mysqli_close($conn);
?>