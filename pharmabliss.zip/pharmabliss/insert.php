<?php
    // Database connection
    $servername = "localhost";
    $username = "root"; // Change to your MySQL username
    $password = ""; // Change to your MySQL password
    $dbname = "pharmacy"; // Change to your database name

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $Firstname = $_POST["fname"];
        $Lastname = $_POST["lname"];
        $Email = $_POST["Email"];
        $Subject = $_POST["Subject"];
        $Message = $_POST["Message"];
  
        $sql = "INSERT INTO data2 (FirstName,LastName,Email,Subject,Message) VALUES ('$Firstname', '$Lastname ', '$Email','$Subject','$Message')";
        if ($conn->query($sql) === TRUE) {
            echo "<div class='alert alert-success' role='alert'>New record created successfully</div>";
        } else {
            echo "<div class='alert alert-danger' role='alert'>Error: " . $sql . "<br>" . $conn->error . "</div>";
        }
    }
    $conn->close();
    ?>